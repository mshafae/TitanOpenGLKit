var searchData=
[
  ['base_5fface',['base_face',['../a00012.html#ae7c1f35cf657c7bbe9eae2b39e44f728',1,'gli::texture']]],
  ['base_5flayer',['base_layer',['../a00012.html#a1aeb020d8f82035e607b209c3841dee2',1,'gli::texture']]],
  ['base_5flevel',['base_level',['../a00012.html#a01c07293e367b293736943e92f6a9e98',1,'gli::texture']]],
  ['block_5fextent',['block_extent',['../a00074.html#a8ed69f83293f50cafb2d147d609e2a96',1,'gli']]],
  ['block_5fsize',['block_size',['../a00074.html#ae8ca05b97f1deac7bf5a50468868a449',1,'gli']]]
];
